import { useEffect, useState } from 'react';
import AddExpenseForm from './Components/AddExpenseForm';
import Charts from './Components/Charts';
import Summary from './Components/Summary';
import { getExpenses, getSalary } from './Components/Services/GoogleSheetAPI';
import { generatePDF } from './Components/Utils/pdfGenerator';
import { exportToExcel } from './Components/Utils/excelExport';

function App() {
  const [expenses, setExpenses] = useState([]);
  const [salary, setSalaryVal] = useState(0);

  const loadData = async () => {
    const res = await getExpenses();
    const salaryData = await getSalary();
    setExpenses(res.slice(1)); // Skip headers
    setSalaryVal(salaryData.data.salary || 0);
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <div>
      <h1>Expense Note App</h1>
      <Summary salary={salary} expenses={expenses} />
      <AddExpenseForm onAdd={loadData} />
      <Charts expenses={expenses} />
      <button onClick={() => generatePDF(expenses)}>Download PDF Report</button>
      <button onClick={() => exportToExcel(expenses)}>Export to Excel</button>
    </div>
  );
}

export default App;
