import axios from 'axios';


const BASE_URL = 'https://script.google.com/macros/s/AKfycbzzJg8y8pWm7_HBFx9HRq7eyY_-8XM42QWDrRaJTqqWziwXaD1cux1OWgsjNC1R0mfkLA/exec';

export const addExpense = (data) => {
  return axios.post(BASE_URL, data);
};

export const getExpenses = async () => {
  const res = await axios.get(BASE_URL + '?action=getExpenses');
  console.log(res.data);
  
  return res.data;
};

export const setSalary = (salary) => {
  return axios.get(`${BASE_URL}?action=setSalary&salary=${salary}`);
};

export const getSalary = () => {
  return axios.get(`${BASE_URL}?action=getSalary`);
};
