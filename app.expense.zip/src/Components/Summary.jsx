export default function Summary({ salary, expenses }) {
  const total = expenses.reduce((acc, curr) => acc + parseFloat(curr[2]), 0);
  const savings = salary - total;

  return (
    <div>
      <p>Total Expenses: ₹{total}</p>
      <p>Savings: ₹{savings}</p>
    </div>
  );
}
