import * as XLSX from 'xlsx';

export const exportToExcel = (expenses) => {
  const ws = XLSX.utils.aoa_to_sheet([['Date', 'Category', 'Amount', 'Notes'], ...expenses]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Expenses');
  XLSX.writeFile(wb, 'expense_report.xlsx');
};
