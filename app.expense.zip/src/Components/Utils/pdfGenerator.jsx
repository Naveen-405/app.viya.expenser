import jsPDF from 'jspdf';
import 'jspdf-autotable';

export const generatePDF = (expenses) => {
  const doc = new jsPDF();
  doc.text('Monthly Expense Report', 14, 20);
  doc.autoTable({
    head: [['Date', 'Category', 'Amount', 'Notes']],
    body: expenses.map(row => row)
  });
  doc.save('monthly-expense-report.pdf');
};
