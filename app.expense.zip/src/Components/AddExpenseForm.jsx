import { useState } from 'react';
import { addExpense } from './Services/GoogleSheetAPI';

const categories = ['Food', 'Transport', 'Bills', 'Entertainment', 'Other'];

export default function AddExpenseForm({ onAdd }) {
  const [category, setCategory] = useState('Food');
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    await addExpense({ category, amount: parseFloat(amount), notes });
    onAdd(); // Refresh parent data
    setAmount('');
    setNotes('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <select value={category} onChange={e => setCategory(e.target.value)}>
        {categories.map(cat => <option key={cat}>{cat}</option>)}
      </select>
      <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="Amount" required />
      <input type="text" value={notes} onChange={e => setNotes(e.target.value)} placeholder="Notes" />
      <button type="submit">Add Expense</button>
    </form>
  );
}
