import { Pie } from 'react-chartjs-2';

export default function Charts({ expenses }) {
  const categoryTotals = expenses.reduce((acc, [_, category, amount]) => {
    acc[category] = (acc[category] || 0) + parseFloat(amount);
    return acc;
  }, {});

  const data = {
    labels: Object.keys(categoryTotals),
    datasets: [{
      data: Object.values(categoryTotals),
      backgroundColor: ['#ff6384', '#36a2eb', '#ffce56', '#4caf50', '#9c27b0']
    }]
  };

  return <Pie data={data} />;
}
